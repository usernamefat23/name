
addon = WorkshopFileBase( "addon", {} )
